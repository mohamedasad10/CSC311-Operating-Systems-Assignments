//4271451
//Mohamed Asad Azim Bandarkar
//OS P1 Ex3 Q2

#include <stdio.h>

int main() {
  int num = 10;      
  int *ipointer = &num;    //Declare pointer and initialize it with the address of 'num'

  printf("ipointer is %p\n", (void *)ipointer);       //Address stored in 'ipointer'    
  printf("The value at ipointer is %d\n", *ipointer); //Value pointed to by 'ipointer'    

  ipointer = ipointer + 1;    

  printf("ipointer incremented by 1 is %p\n", (void *)ipointer);   //new address stored in 'ipointer'         

  return 0;
}
