//4271451
//Mohamed Asad Azim Bandarkar
//OS P1 Ex3 Q3

#include <stdio.h>

int main() {
  char c = 'z';
  char *cp = &c;

  printf("cp is 0x%08x\n", cp);
  printf("The character at cp is %c\n", *cp);

  cp = cp+1;
  printf("cp is 0x%08x\n", cp);

  return 0;
}