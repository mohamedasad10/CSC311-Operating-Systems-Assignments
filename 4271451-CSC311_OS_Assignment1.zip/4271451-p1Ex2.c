//4271451
//Mohamed Asad Azim Bandarkar
//OS P1 Ex2

#include <stdio.h>

void foo1(int xval) {
  int x;
  x = xval;

  printf("Address of x = 0x%x\n Value of x = %d \n ", &x, x);
}

void foo2(int dummy) {
  int y;
  
  printf("Address of y = 0x%x\nValue of y = %d \n", &y, y);
}




int main() {
  
  foo1(7);
  foo2(11);
  return 0;
}
