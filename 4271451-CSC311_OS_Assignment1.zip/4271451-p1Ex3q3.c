//4271451
//Mohamed Asad Azim Bandarkar
//OS P1 Ex3 Q3

#include <stdio.h>

int main() {
  double d = 3.14159;        
  double *dpointer = &d;        //Declare pointer and initialize it with the address of 'd'

  printf("dpointer is %p\n", (void *)dpointer);   //Address stored in 'dpointer'
  printf("The value at dpointer is %lf\n", *dpointer); //value pointed to by 'dpointer'

  dpointer = dpointer + 1;    //Next memory location of type 'double'

  printf("dpointer incremented by 1 is %p\n", (void *)dpointer);           //New address stored in 'dpointer'

  return 0;
}
