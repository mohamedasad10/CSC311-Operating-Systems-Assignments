/*4271451 - Mohamed Asad Bandarkar
CSC311 P2*/
#include <stdio.h>
#include <pthread.h>

//stantiate functions that are going to be used
void *computation1();
void *computation2();

int main()
{
    //declare any variable
    pthread_t thread1;
    pthread_t thread2;
    
    //declare thread for thread 1
    pthread_create(&thread1,NULL,computation1,NULL);
    printf("Parent: Thread created\n");
    pthread_join(thread1,NULL);
    printf("Thread 1 Complete\n");
    
    //initialize and call thread function
    
    
    /**/////////////////////////Thread2///////////////////////////////*/
        //declare any variable
    
    
    //declare thread
    pthread_create(&thread2,NULL,computation2,NULL);
    printf("Parent: Thread created\n");
    pthread_join(thread2,NULL);
    printf("Thread 2 Complete");
    
    //initialize and call thread function

    return 0;
}


void *computation1(){
    printf("Child: Thread is running\n");
    long sum = 0;
    for (long i = 0; i <1000000000; i++){
    sum += 1;
    }
    
}

void *computation2(){
    printf("Child: Thread is running\n");
    long sum = 0;
    for (long i = 0; i <1000000000; i++){
    sum += 1;
    }
    
}