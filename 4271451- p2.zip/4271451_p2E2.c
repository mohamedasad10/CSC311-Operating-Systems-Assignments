/*4271451 - Mohamed Asad Bandarkar
CSC311 P2
References: https://www.cs.cmu.edu/afs/cs/academic/class/15492-f07/www/pthreads.html
https://www.geeksforgeeks.org/posix-threads-in-os/
https://www.geeksforgeeks.org/multithreading-in-c/?ref=header_search
https://stackoverflow.com/questions/16679718/what-is-the-best-way-to-get-tight-timing-of-a-thread-in-c-pthreads*/

#include <stdio.h>
#include <pthread.h>
#include <time.h> 
#include <stdlib.h> 
#include <unistd.h> 

void *computation1(void *arg);
void *computation2(void *arg);

int main() {
    pthread_t thread1;
    pthread_t thread2;
    clock_t start_time_thread1, end_time_thread1; //Variables to hold start and end times for thread 1
    clock_t start_time_thread2, end_time_thread2; //Variables to hold start and end times for thread 2
    double total_duration = 0.0; //Variable to hold total duration
    int num_threads = 2;// Number of threads
    
    long *shared_variable_thread1 = malloc(sizeof(long)); //Shared variable for thread 1
    long *shared_variable_thread2 = malloc(sizeof(long)); //Shared variable for thread 2

    *shared_variable_thread1 = 1; //value to pass to thread 1
    *shared_variable_thread2 = 2; //value to pass to thread 2

    start_time_thread1 = clock(); //Start time for thread 1
    pthread_create(&thread1, NULL, computation1, (void *)shared_variable_thread1);
    //printf("Parent: Thread 1 created\n");

    start_time_thread2 = clock(); //Start time for thread 2
    pthread_create(&thread2, NULL, computation2, (void *)shared_variable_thread2);
    //printf("Parent: Thread 2 created\n");

    pthread_join(thread1, NULL);
    end_time_thread1 = clock(); //End time for thread 1
    
    
    //Waiting for thread 1 to finish and capturing its end time
    double thread1_duration = ((double) (end_time_thread1 - start_time_thread1)) / CLOCKS_PER_SEC;
    printf("Thread 1 took %f seconds to execute\n", thread1_duration);
    total_duration += thread1_duration;

    pthread_join(thread2, NULL);
    end_time_thread2 = clock(); //End time for thread 2
    
    
    //Waiting for thread 2 to finish and capturing its end time
    double thread2_duration = ((double) (end_time_thread2 - start_time_thread2)) / CLOCKS_PER_SEC;
    printf("Thread 2 took %f seconds to execute\n", thread2_duration);
    total_duration += thread2_duration;

    printf("Thread 1 and Thread 2 took %f seconds to execute\n", total_duration);
    
    
    //Printing the total duration for both threads
    double average_time = total_duration / num_threads;
    printf("Average time taken was %f\n", average_time);

    return 0;
}

void *computation1(void *arg) {
    long *shared_variable = (long *)arg;
    printf("Thread1: %ld\n", *shared_variable);
    pthread_exit(NULL);
}

void *computation2(void *arg) {
    long *shared_variable = (long *)arg;
    printf("Thread2: %ld\n", *shared_variable);
    pthread_exit(NULL);
}
