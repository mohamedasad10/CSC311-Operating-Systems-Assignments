/*Mohamed Asad Bandarkar
4271451
CSC311 Practical 3 Q2
References: 
https://docs.oracle.com/cd/E19683-01/806-6867/sync-ex-13/index.html#:~:text=When%20a%20thread%20successfully%20acquires,count%20is%20decremented%20by%20one.
https://stackoverflow.com/questions/37569571/is-a-mutex-necessary-when-only-inc-decrementing-a-variable
https://stackoverflow.com/questions/46767423/how-can-i-lock-twice-with-the-same-mutex-on-the-same-thread
https://stackoverflow.com/questions/49720718/how-to-control-mutex-lock-and-unlock
https://www.geeksforgeeks.org/use-of-flag-in-programming/
https://www.geeksforgeeks.org/thread-functions-in-c-c/?ref=header_search
*/

#include <stdio.h>                
#include <pthread.h>              

float shared_variable = 64.0;     //shared float variable
pthread_mutex_t mutex;            //mutex for synchronization
pthread_cond_t increment, decrement, double_cond, halve;  //condition variables for synchronization

//declare 4 flags to track completion of the operations
int incr_complete = 0;
int decr_complete = 0;
int double_complete = 0; 
int halve_complete = 0;  


void* incr(void* arg) {           
    pthread_mutex_lock(&mutex);   //mutex locked
    shared_variable += 1.0;       //increment the shared variable
    
    printf("Variable incremented: %.2f\n", shared_variable);  //print the incremented value
    
    incr_complete = 1;                //sets the flag whichh indicates completion of increment operation
    pthread_cond_signal(&decrement);  //signals the decrement thread that the increment operation is done so it can move on to decrement
    pthread_mutex_unlock(&mutex); //unlocks the mutex to release the lock
    return NULL;                  
}


void* decr(void* arg) {           
    pthread_mutex_lock(&mutex);   //mutex locked
    while (!incr_complete)            //wait for the increment operation to complete
        pthread_cond_wait(&decrement, &mutex);  
    shared_variable -= 1.0;       //decrement shared variable
    
    printf("Variable decremented: %.2f\n", shared_variable); //print the decremented value
    
    decr_complete = 1;                //sets the flag which indicates completion of decrement operation
    pthread_cond_signal(&double_cond);  //signal the double thread that decrement operation is done
    pthread_mutex_unlock(&mutex); //unlock mutex
    return NULL;                  // Return NULL as the function is of type void*
}


void* double_var(void* arg) {     
    pthread_mutex_lock(&mutex);   //mutex locked
    while (!decr_complete)            //wait for the increment operation to complete
        pthread_cond_wait(&double_cond, &mutex);  
    shared_variable *= 2.0;       // Double the shared variable
    
    printf("Variable doubled: %.2f\n", shared_variable);    //print the doubled value
    
    double_complete = 1;              //sets the flag which indicates completion of double operation
    pthread_cond_signal(&halve);  // Signal the halve thread that double operation is done
    pthread_mutex_unlock(&mutex); //unlock mutex
    return NULL;                  // Return NULL as the function is of type void*
}


void* halve_var(void* arg) {      
    pthread_mutex_lock(&mutex);   //mutex locked
    while (!double_complete)          //wait for the increment operation to complete
        pthread_cond_wait(&halve, &mutex);   // Wait on the condition variable
    shared_variable /= 2.0;       // Halve the shared variable
    
    printf("Variable halved: %.2f\n", shared_variable);     //print the halved value
    
    halve_complete = 1;               // Set the flag to indicate completion of halve operation
    pthread_mutex_unlock(&mutex); //unlock mutex
    return NULL;                  
}



int main() {
    pthread_t tid_incr, tid_decr, tid_double, tid_halve;  //declare thread identifiers

    pthread_mutex_init(&mutex, NULL);  //initializing the mutex
    
    //initialize the 4 condition variables
    pthread_cond_init(&increment, NULL);  
    pthread_cond_init(&decrement, NULL);
    pthread_cond_init(&double_cond, NULL);
    pthread_cond_init(&halve, NULL);

    //creates threads for each operation
    pthread_create(&tid_incr, NULL, incr, NULL);
    pthread_create(&tid_decr, NULL, decr, NULL);
    pthread_create(&tid_double, NULL, double_var, NULL);
    pthread_create(&tid_halve, NULL, halve_var, NULL);

    //waiting for threads to finish
    pthread_join(tid_incr, NULL);
    pthread_join(tid_decr, NULL);
    pthread_join(tid_double, NULL);
    pthread_join(tid_halve, NULL);
    
    //destroying the mutex and condition variables
    pthread_mutex_destroy(&mutex);  
    pthread_cond_destroy(&increment);
    pthread_cond_destroy(&decrement);
    pthread_cond_destroy(&double_cond);
    pthread_cond_destroy(&halve);

    return 0;  //return 0 which indicates successful execution
}
